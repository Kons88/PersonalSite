#######################################################################
## WEB-SCRAPER FOR LinkedIn:
##=====================================================================
## HTTP error 429: A security measure for preventing brute force
## attacks. The code below waits and retries by itself at each failure 
## (for 30s, 60s and finally 90s before quitting). 
## If it still fails, stop and wait 1-2 hours, or reset the router to 
## get a new IP.
#######################################################################

#######################################################################
## Libraries to load:
##=====================================================================
import html           # html.unescape turns '&amp;' back into '&'.
import json           
import random         # random pauses between requests.
import re             # regular expressions (regex).
import time           
from datetime import date
from urllib.parse import quote   # turns spaces into %20 etc. for URLs

import pandas as pd                      
import requests                          
from bs4 import BeautifulSoup            
from selenium import webdriver           
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
#######################################################################

#######################################################################
## REGEX Glossary for statistical tool patterns which we shall need:
##=====================================================================
# \\b           is a word boundary (so for example \\bR\\b matches 'R' alone but not the R in 'Rust').
# \\s           is a whitespace (so power\\s?bi matches 'powerbi' and 'power bi').
# a|b           a or b.
# (a|b)         a group, only used for (win|open)\\s?bugs here.
# x?            x is optional (so e-?views matches 'eviews' and 'e-views').
# (?<!&)        negative lookbehind, which is not preceded by &. Look before the match and see that it's not preceded by something.
# (?!\\s*&)     negative lookahead, which is not followed by optional spaces and &. Finds a match that's not followed by something.
# (?=\\s*[,/])  positive lookahead, which is followed by a comma or slash. Here we want it to be followed by something.
# (?<=[,/] )    positive lookbehind, which is preceded by a comma or slash and a space. We want it to be preceded by something.
# [,/]	        take one character from this set.
##=====================================================================
TOOL_PATTERNS = {
    "R":                r"(?<!&)\bR\b(?!\s*&)",          # R, but not "R&D"
    "Python":           r"\bpython\b",
    "SAS":              r"\bSAS\b",
    "MATLAB":           r"\bmatlab\b",
    "Stata":            r"\bstata\b",
    "Eviews":           r"\be-?views\b",
    "Minitab":          r"\bminitab\b",
    "SPSS":             r"\bspss\b",
    "Winbugs/Openbugs": r"\b(win|open)\s?bugs\b",
    "JAGS":             r"\bjags\b",
    "Stan":             r"\bRStan\b|\bPyStan\b|\bStan\b(?=\s*[,/])|(?<=[,/] )Stan\b",
    "SQL":              r"\bsql\b",
    "C/C++":            r"\bC\+\+|\bC\b(?=\s*[,/])(?![#+])|(?<=[,/] )C\b(?![#+])|(?<=[,/])C\b(?![#+])",
    "Rust":             r"\bRust\b",
    "Tableau":          r"\btableau\b",
    "PowerBI":          r"\bpower\s?bi\b",
    "Alteryx":          r"\balteryx\b",
    "Hadoop":           r"\bhadoop\b",
    "Spark":            r"\bPySpark\b|\bApache Spark\b|\bSpark (SQL|MLlib|Streaming)\b|\bSpark\b(?=\s*[,/])|(?<=[,/] )Spark\b",
    "Scala":            r"\bscala\b",
    "SAP":              r"\bSAP\b",
    "Qlik":             r"\bqlik(view|sense)?\b",
    "Hive":             r"\bApache Hive\b|\bHiveQL\b|\bHive\b(?=\s*[,/])|(?<=[,/] )Hive\b",
    "Julia":            r"\bJulia\b",
    "Spotfire":         r"\bspotfire\b",
    "JMP":              r"\bJMP\b",
    "VBA":              r"\bvba\b",
    "Java":             r"\bjava\b",                      # does not match JavaScript
    "MS Access":        r"\b(MS|Microsoft)\s+Access\b",
    "MS Excel":         r"\b(MS|Microsoft|Advanced)\s+Excel\b|\bExcel\b(?=\s*[,/])|(?<=[,/] )Excel\b",
    "MS Azure":         r"\bazure\b",
    "AWS":              r"\bAWS\b|\bamazon web services\b",
    "Git":              r"\bGit\b",
    "ElasticSearch":    r"\belastic\s?search\b",
    "KNIME":            r"\bknime\b",
}

## The tools from the list above which we want to be case sensitive during the web-scrape:
CASE_SENSITIVE = {"R", "SAS", "Stan", "C/C++", "Rust", "Spark", "SAP", "Hive",
                  "Julia", "JMP", "MS Access", "MS Excel", "Git"}

TOOL_NAMES = list(TOOL_PATTERNS)

## Compile every pattern ONCE (faster than rebuilding it for every ad).
## re.IGNORECASE is switched on only for the 'safe' tools that have no problems with their cases XD.
COMPILED = {
    tool: re.compile(pattern, 0 if tool in CASE_SENSITIVE else re.IGNORECASE)
    for tool, pattern in TOOL_PATTERNS.items()
}

##=====================================================================
## The following function takes ONE job description (written in plain 
## text) and returns a vector of 1s and 0s for each corresponding tool.
##====================================================================
def detect_tools(text):
    if text is None:                                   # if no description, then all unknown.
        return {tool: None for tool in TOOL_NAMES}
    return {tool: int(COMPILED[tool].search(text) is not None) for tool in TOOL_NAMES}


## Quick test to see if it works:
def self_test():
    def found(text):
        return [t for t, v in detect_tools(text).items() if v == 1]

    assert found("Skills: R, Python and SQL.") == ["R", "Python", "SQL"]
    assert found("Strong R&D mindset, excel in teamwork") == []
    assert found("Proficient in C++, Java, MS Excel") == ["C/C++", "Java", "MS Excel"]
    assert found("You will have access to Spark clusters") == []
    print("All tests passed.")


#######################################################################
## Checks and Errors:
##=====================================================================
## Downloads a page. On an error (e.g. HTTP 429) it waits and tries
## again up to 3 times, then gives up and returns None instead of
## crashing the whole run:
HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) "
                         "Gecko/20100101 Firefox/128.0"}

def get_page(session, url):
    for attempt in range(1, 4):                        # attempt = 1, 2, 3
        try:
            response = session.get(url, headers=HEADERS, timeout=30)
            response.raise_for_status()                # turns 429, 500... into an error
            return BeautifulSoup(response.text, "html.parser")
        except requests.RequestException:
            print(f"  Problem fetching page, waiting {30 * attempt} seconds...")
            time.sleep(30 * attempt)
    return None


## Removes HTML tags and superfluous objects from a description:
def clean_text(x):
    if x is None:
        return None
    x = re.sub(r"<[^>]+>", " ", x)          # remove tags like <br> or <strong>
    x = html.unescape(x)                    # &amp; -> &   and   &nbsp; -> space
    return re.sub(r"\s+", " ", x).strip()   # squash repeated spaces


#######################################################################
## Selecting all the jobs from one country:
##=====================================================================
## This function scrolls down and clicks on the 'See more jobs' button 
## until LinkedIn either shows no more ads or max.jobs is reached
## (default 1000).
## LinkedIn itself only lets a search go so deep till it breaks or stops
## responding (several hundred ads, or in good cases up to ~1000).
## Around 4-5/ad: So 1000 ads can take about an hour.
## Checkpoints are written to linkedin_checkpoint.rds every 50 ads.
##=====================================================================
INFO_COLS = ["Job ID", "Title", "Company", "Date Posted", "Date Scraped"]
END_COLS = ["Seniority Level", "Industry", "Country", "Term Searched", "Description"]


def linkedin_search(country, term_searched, keep_description=True,
                    max_jobs=1000, headless=False):

    ## ---- Step 1: open Firefox and collect the job links ----
    options = Options()
    if headless:
        options.add_argument("-headless")              # run without opening a window.
    driver = webdriver.Firefox(options=options)        

    try:                                               
        ## Create the URL (%22: Double Quotes, %20: Space):
        url = ("https://www.linkedin.com/jobs/search?keywords=%22" + quote(term_searched) +
               "%22&location=" + quote(country) + "&position=1&pageNum=0")
        driver.get(url)
        time.sleep(2)

        def count_ads():
            return len(driver.find_elements(By.CSS_SELECTOR, "a[href*='/jobs/view/']"))

        ## Keep scrolling and clicking 'See more jobs', until either no new job ads appear, or until max_jobs ads have been loaded:
        last_count = 0
        no_growth = 0
        while True:
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(random.uniform(1.5, 3))

            ## Click the 'See more jobs' button, if LinkedIn is showing it (some countries have only a few jobs):
            try:
                buttons = driver.find_elements(By.CSS_SELECTOR, ".infinite-scroller__show-more-button")
                if buttons:
                    buttons[0].click()
            except Exception:
                pass                                   # no button or not clickable? Then ignore it.
            time.sleep(1)

            n = count_ads()
            print(f"  Loaded about {n} job ads so far...")

            ## Stop if the number did not grow 3 times in a row (so no more results):
            no_growth = 0 if n > last_count else no_growth + 1
            last_count = n
            if no_growth >= 3 or n >= max_jobs:
                break

        page_title = driver.title
        soup = BeautifulSoup(driver.page_source, "html.parser")
    finally:
        driver.quit()                                  # close Firefox, even after an error.

    ## ---- Step 2: clean the list of links ----
    all_links = [a["href"] for a in soup.find_all("a", href=True)]

    ## Select only the job ads:
    links = [l for l in all_links if "result_search-card" in l or "/jobs/view/" in l]

    ## Remove duplicates (the same job can appear with different tracking codes after the "?"), so we compare the links WITHOUT the "?..." part. 
    unique = {}
    for l in links:
        unique.setdefault(l.split("?")[0], l)
    base_links = list(unique)[:max_jobs]
    links = list(unique.values())[:max_jobs]

    print(f"Found {len(links)} unique job ads for '{term_searched}' in {country}")

    ## If nothing was found, stop here and show the last result of our browser:
    if not links:
        print(f"No job links found. The page title was: '{page_title}'")
        print(f"Total <a> links on the page: {len(all_links)}")
        return None

    ## ---- Step 3: visit every job and detect the tools ----
    rows = []
    session = requests.Session()                       # re-uses the connection between requests.

    for i, (link, base) in enumerate(zip(links, base_links), start=1):

        ## Wait a random 2-5 seconds between job ads (fewer 429 errors):
        time.sleep(random.uniform(2, 5))

        page = get_page(session, link)
        if page is None:
            print(f"  Skipping job {i} (page could not be loaded)")
            continue

        ## The job data are stored in a script of this type: "application/ld+json".
        ## Look it up by its type and not by its position:
        info = {}
        tag = page.find("script", type="application/ld+json")
        if tag is not None and tag.string:
            try:
                info = json.loads(tag.string)
            except json.JSONDecodeError:
                info = {}

        ## Job Description: first choice is the JSON, second choice is the visible text on the page:
        desc = info.get("description")
        if not desc:
            box = page.select_one(".show-more-less-html__markup")
            desc = box.get_text(" ") if box else None
        desc = clean_text(desc)

        ## Seniority and Industry: find them by their HEADER TEXT, not by their position
        ## (LinkedIn sometimes leaves them out):
        criteria = {}
        for item in page.select(".description__job-criteria-item"):
            header = item.select_one("h3")
            value = item.select_one("span")
            if header and value:
                criteria[header.get_text(strip=True).lower()] = value.get_text(strip=True)
        seniority = next((v for k, v in criteria.items() if "seniority" in k), None)
        industry = next((v for k, v in criteria.items() if "industr" in k), None)

        ## Fill the row (into a dictionary):
        match = re.search(r"\d+$", base)
        company = (info.get("hiringOrganization") or {}).get("name")
        row = {
            "Job ID": match.group(0) if match else None,
            "Title": info.get("title"),
            "Company": company,
            "Date Posted": info.get("datePosted"),
            "Date Scraped": str(date.today()),
            **detect_tools(desc),                      # ** unpacks the 35 tool columns here.
            "Seniority Level": seniority,
            "Industry": industry,
            "Country": country,
            "Term Searched": term_searched,
            "Description": desc,
        }
        rows.append(row)

        if i % 10 == 0:
            print(f"  {i} / {len(links)} done")

        ## Checkpoint every 50 ads, so if it crashes, it does not lose everything:
        if i % 50 == 0:
            pd.DataFrame(rows).to_csv("linkedin_checkpoint.csv", index=False, encoding="utf-8")

   
    df = pd.DataFrame(rows, columns=INFO_COLS + TOOL_NAMES + END_COLS)

    ## Delete the raw text if you do not want it:
    if not keep_description:
        df = df.drop(columns="Description")

    return df


## Examples:
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        self_test()
    else:
        pass
        # my_data = linkedin_search("England", "Data Scientist")
        # my_data_1 = linkedin_search("England", "Statistician")
        # my_data = pd.concat([my_data, my_data_1], ignore_index=True)
        #
        # my_data_1 = linkedin_search("Norway", "Data Scientist")
        # my_data = pd.concat([my_data, my_data_1], ignore_index=True)
        #
        ## Save the result:
        # my_data.to_csv("linkedin_jobs.csv", index=False, encoding="utf-8")
        #
        ## Quick look (share of ads mentioning each tool, largest first):
        # print(my_data[TOOL_NAMES].mean().sort_values(ascending=False))
